#  SQL Assignment No. 2

use hr;

#1
SELECT first_name "First Name",  last_name "Last Name" FROM employees;

#2
SELECT DISTINCT department_id FROM employees;

#3
SELECT * FROM employees ORDER BY first_name DESC;

#4
SELECT first_name, last_name, salary, salary*.15 PF FROM employees;

#5
SELECT employee_id, first_name, last_name, salary FROM employees ORDER BY salary;

#6
SELECT SUM(salary) FROM employees;

#7
SELECT MAX(salary), MIN(salary) FROM employees;

#8
SELECT AVG(salary), COUNT(*) FROM employees;

#9
SELECT COUNT(*) FROM employees;

#10
SELECT COUNT(DISTINCT job_id) FROM employees;

#11
SELECT UPPER(first_name) FROM employees;

#12
SELECT SUBSTRING(first_name,1,3) FROM employees;

#13
SELECT TRIM(first_name) FROM employees;

#14
SELECT first_name,last_name, LENGTH(first_name)+LENGTH(last_name)  'Length of  Names' FROM employees;

#15
SELECT * FROM employees WHERE  first_name REGEXP  '[0-9]';

#16
SELECT first_name, last_name, salary FROM employees WHERE salary NOT BETWEEN 10000 AND 15000;

#17
SELECT first_name, last_name, department_id FROM employees WHERE department_id IN (30, 100) ORDER BY  department_id  ASC;

#18
SELECT first_name, last_name, salary, department_id FROM employees WHERE salary NOT BETWEEN 10000 AND 15000 AND department_id IN (30, 100);

#19
SELECT first_name, last_name, hire_date FROM employees WHERE YEAR(hire_date)  LIKE '1987%';

#20
SELECT first_name FROM employees WHERE first_name LIKE '%b%' AND first_name LIKE '%c%';

#21
SELECT last_name, job_id, salary FROM employees WHERE job_id IN ('IT_PROG', 'SH_CLERK') AND salary NOT IN (4500,10000, 15000);

#22
SELECT last_name FROM employees WHERE last_name LIKE '______';

#23
SELECT last_name FROM employees WHERE last_name LIKE '__e%';

#24
SELECT job_id, GROUP_CONCAT(employee_id, ' ')  'Employees ID' FROM employees GROUP BY job_id;

#25
UPDATE employees SET phone_number = REPLACE(phone_number, '124', '999') WHERE phone_number LIKE '%124%';

#26
SELECT * FROM employees WHERE LENGTH(first_name) >= 8;

#27
UPDATE employees SET email = CONCAT(email, '@example.com');

#28
SELECT RIGHT(phone_number, 4) as 'Ph.No.' FROM employees;

#29
SELECT location_id, street_address, 
SUBSTRING_INDEX(REPLACE(REPLACE(REPLACE(street_address,',',' '),')',' '),'(',' '),' ',-1) AS 'Last--word-of-street_address' 
FROM locations;

#30
SELECT * FROM locations WHERE LENGTH(street_address) <= (SELECT  MIN(LENGTH(street_address)) FROM locations);

#31
SELECT job_title, SUBSTR(job_title,1, INSTR(job_title, ' ')-1) FROM jobs;

#32
SELECT first_name, last_name FROM employees WHERE INSTR(last_name,'C') > 2;

#33
SELECT first_name "Name", LENGTH(first_name) "Length" FROM employees
WHERE first_name LIKE 'J%' OR first_name LIKE 'M%' OR first_name LIKE 'A%' ORDER BY first_name ;

#34
SELECT first_name, LPAD(salary, 10, '$') SALARY FROM employees;

#35
SELECT left(first_name, 8), REPEAT('$', FLOOR(salary/1000)) 'SALARY($)', salary FROM employees ORDER BY salary DESC;

#36
SELECT employee_id,first_name,last_name,hire_date FROM employees WHERE POSITION("07" IN DATE_FORMAT(hire_date, '%d %m %Y'))>0;


#END



# Northwind Database

use northwind;

#1
SELECT ProductName, QuantityPerUnit FROM Products;

#2
SELECT ProductID, ProductName FROM Products WHERE Discontinued = "False" ORDER BY ProductName;

#3
SELECT ProductID, ProductName FROM Products WHERE Discontinued = 1 ORDER BY ProductName;

#4
SELECT ProductName, UnitPrice FROM Products ORDER BY UnitPrice DESC;

#5
SELECT ProductID, ProductName, UnitPrice FROM Products WHERE (((UnitPrice)<20) AND ((Discontinued)=False)) ORDER BY UnitPrice DESC;

#6
SELECT ProductName, UnitPrice FROM Products WHERE (((UnitPrice)>=15 And (UnitPrice)<=25) AND ((Products.Discontinued)=False))
ORDER BY Products.UnitPrice DESC;

#7
SELECT DISTINCT ProductName, UnitPrice FROM Products WHERE UnitPrice > (SELECT avg(UnitPrice) FROM Products) ORDER BY UnitPrice;

#8
SELECT DISTINCT ProductName as Twenty_Most_Expensive_Products, UnitPrice FROM Products AS a WHERE 20 >= (SELECT COUNT(DISTINCT UnitPrice)
FROM Products AS b WHERE b.UnitPrice >= a.UnitPrice) ORDER BY UnitPrice desc;

#9
SELECT Count(ProductName) FROM Products GROUP BY Discontinued;

#10
SELECT ProductName,  UnitsOnOrder , UnitsInStock FROM Products WHERE (((Discontinued)=False) AND ((UnitsInStock)<UnitsOnOrder));


#END